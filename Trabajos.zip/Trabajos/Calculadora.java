public class Calculadora {
  
  public double ejecutarOperacion (Operacion operacion){
    return operacion.calcular();
  }
}
