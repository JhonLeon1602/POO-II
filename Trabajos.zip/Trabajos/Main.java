
import java.util.Scanner;

public class Main {
  
  public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
      Calculadora calculadora = new Calculadora();

      System.out.println("Ingrese el primer numero");
      double n1 = scanner.nextDouble();

      System.out.println("Ingrese el segundo numero");
      double n2 = scanner.nextDouble();

      System.err.println("Seleccione la operacion +, -,*,/");
      char operacion = scanner.next().charAt(0);

      Operacion op;

      switch (operacion){
        case '+':
          op = new Suma(n1,n2);
          break;
        case '-':
          op = new Resta(n1,n2);
          break;
        case '*':
          op = new Multiplicacion(n1, n2);
          break;
        case '/':
          op = new Division(n1,n2);
          break;
        default:
          System.out.println("operacion no es valida");
          return;
      }

      double resultado = calculadora.ejecutarOperacion(op);
      System.out.println("Resultado "+resultado);
  }
}
